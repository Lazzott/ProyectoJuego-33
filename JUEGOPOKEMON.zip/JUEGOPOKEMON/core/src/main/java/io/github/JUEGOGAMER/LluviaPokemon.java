package io.github.JUEGOGAMER;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.math.MathUtils;

public class LluviaPokemon extends LluviaTemplate {

    private AbstractFactory factory;  // Fábrica abstracta

    public LluviaPokemon(Texture gota, Texture gotaMala, Sound ss, Music mm, EstrategiaMovimiento est) {
        super(ss, mm, est);
        // Inicializar la fábrica concreta pasando las texturas necesarias
        this.factory = new FactoryPokemon();
    }

    @Override
    protected Objetos crearObjetoLluvia() {
        float x = MathUtils.random(800, 1600);
        float y = MathUtils.random(0, 480 - 64);

        int tipo = MathUtils.random(1, 10);
        if (tipo <= 5) {
            return factory.crearPokeball(x, y);  // Usar la fábrica para crear una Pokeball
        } else if (tipo <= 9) {
            return factory.creargastly(x, y);  // Usar la fábrica para crear un Gengar
        } else {
            return factory.crearJigglypuff(x, y);  // Usar la fábrica para crear un Jigglypuff
        }
    }
}

