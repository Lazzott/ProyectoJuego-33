package io.github.JUEGOGAMER;

public class MovimientoRapido implements EstrategiaMovimiento {
    @Override
    public void actualizarLluvia(Objetos objeto, float deltaTime) {
        objeto.getPosicion().x -= 500 * deltaTime; // Movimiento rápido
    }
}
