package io.github.JUEGOGAMER;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Array;

public abstract class LluviaTemplate {
    private Array<Objetos> objetosLluvia;
    private Sound dropSound;
    private Music rainMusic;
    private static final int MAX_OBJETOS = 5;  // Máximo de objetos en pantalla
    private float tiempoGeneracion;  // Temporizador para generar objetos
    private float intervaloGeneracion = 0.2f;  // Intervalo de tiempo entre la generación de objetos (en segundos)

    // Estrategia de movimiento (para rápido/lento)
    private EstrategiaMovimiento estrategiaMovimiento;

    public LluviaTemplate(Sound ss, Music mm, EstrategiaMovimiento estrategiaInicial) {
        this.dropSound = ss;
        this.rainMusic = mm;
        this.objetosLluvia = new Array<>();
        this.tiempoGeneracion = 0f;  // Inicializamos el temporizador
        this.estrategiaMovimiento = estrategiaInicial;  // Estrategia inicial de movimiento
    }

    // Método plantilla
    public void crear() {
        objetosLluvia.clear();
        rainMusic.setLooping(true);
        rainMusic.play();
    }

    // Paso común: generar objetos en intervalos regulares
    public void generarObjetos() {
        tiempoGeneracion += Gdx.graphics.getDeltaTime();

        if (tiempoGeneracion >= intervaloGeneracion) {
            if (objetosLluvia.size < MAX_OBJETOS) {
                Objetos objeto = crearObjetoLluvia();  // Crear el objeto usando el método abstracto
                objetosLluvia.add(objeto);  // Añadir el objeto a la lista
                tiempoGeneracion = 0f;  // Reiniciar el temporizador
            }
        }
    }

    // Paso específico: cada subclase implementará este método para crear el objeto específico de lluvia
    protected abstract Objetos crearObjetoLluvia();

    // Método común para actualizar el movimiento y la colisión
    public boolean actualizarMovimiento(Entrenador tarro) {
        for (int i = 0; i < objetosLluvia.size; i++) {
            Objetos objeto = objetosLluvia.get(i);
            estrategiaMovimiento.actualizarLluvia(objeto, Gdx.graphics.getDeltaTime()); // Usar la estrategia de movimiento

            if (objeto.getPosicion().x + 64 < 0) {
                objetosLluvia.removeIndex(i);
                continue;
            }

            if (objeto.getPosicion().overlaps(tarro.getArea()) && objeto instanceof EfectoColision) {
                ((EfectoColision) objeto).aplicarEfecto(tarro);
                dropSound.play();
                objetosLluvia.removeIndex(i);

                if (tarro.getVidas() <= 0)
                    return false; // Game over
            }
        }
        return true;
    }

    // Actualizar el dibujo de los objetos de lluvia
    public void actualizarDibujoLluvia(SpriteBatch batch) {
        for (Objetos objeto : objetosLluvia) {
            objeto.dibujar(batch);
        }
    }

    // Cambiar la estrategia de movimiento
    public void setEstrategiaMovimiento(EstrategiaMovimiento nuevaEstrategia) {
        this.estrategiaMovimiento = nuevaEstrategia;
    }

    // Método para destruir los recursos (sonido y música)
    public void destruir() {
        dropSound.dispose();
        rainMusic.dispose();
    }

    // Método para pausar la música
    public void pausar() {
        rainMusic.stop();
    }

    // Método para continuar la música
    public void continuar() {
        rainMusic.play();
    }
}



