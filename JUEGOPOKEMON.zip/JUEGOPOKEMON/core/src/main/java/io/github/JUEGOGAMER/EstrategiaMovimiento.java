package io.github.JUEGOGAMER;

public interface EstrategiaMovimiento {
    void actualizarLluvia(Objetos objeto, float deltaTime);
}
