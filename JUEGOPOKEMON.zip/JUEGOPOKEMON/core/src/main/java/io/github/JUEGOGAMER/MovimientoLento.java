package io.github.JUEGOGAMER;

public class MovimientoLento implements EstrategiaMovimiento {
    @Override
    public void actualizarLluvia(Objetos objeto, float deltaTime) {
        objeto.getPosicion().x -= 200 * deltaTime; // Movimiento lento
    }
}

