package io.github.JUEGOGAMER;

import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.Gdx;

public class SoundManager {
    private static SoundManager instance;
    private Music backgroundMusic;
    private Sound hurtSound;
    private Sound dropSound;

    // Constructor privado para evitar instanciación externa
    private SoundManager() {
        backgroundMusic = Gdx.audio.newMusic(Gdx.files.internal("y2mate.com - Cancion del pueblo lavanda.mp3"));
        hurtSound = Gdx.audio.newSound(Gdx.files.internal("hurt.ogg"));
        dropSound = Gdx.audio.newSound(Gdx.files.internal("drop.wav"));
    }

    // Método estático para obtener la única instancia
    public static SoundManager getInstance() {
        if (instance == null) {
            instance = new SoundManager(); // Si no existe, se crea una nueva instancia
        }
        return instance;
    }

    // Métodos para controlar los sonidos
    public void playBackgroundMusic() {
        if (!backgroundMusic.isPlaying()) {
            backgroundMusic.setLooping(true);
            backgroundMusic.play();
        }
    }

    public void stopBackgroundMusic() {
        backgroundMusic.stop();
    }

    public void playHurtSound() {
        hurtSound.play();
    }

    public void playDropSound() {
        dropSound.play();
    }

    public void dispose() {
        backgroundMusic.dispose();
        hurtSound.dispose();
        dropSound.dispose();
    }

    public Music getBackgroundMusic() {
        return backgroundMusic;
    }

    public Object getHurtSound() {
        return hurtSound;
    }

    public Object getDropSound() {
        return dropSound;
    }
}

