package io.github.JUEGOGAMER;

public interface EfectoColision {
    void aplicarEfecto(Entrenador tarro);
}


